/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progpoe1;

/**
 *
 * @author Nicollette Bullet
 */
import java.util.Scanner;
import java.util.regex.Pattern;

public class PROgPoE {

    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        
        String userName;
        String phoneNumber;
        String passWord;
        
        System.out.println("\n====Registration====");
        
        userName = getValidUsername(scanner);
        passWord = getValidPassword(scanner);
        phoneNumber = getValidPhonenumber(scanner);
        
        boolean registered = registerUser(userName, passWord, phoneNumber);
        if (!registered) {
            System.out.println("Registration failed. Exiting application.");
            scanner.close();
            return;
        }  
        
        System.out.println("\n====Login====");  
        boolean loginSuccess = false;
        
        while (!loginSuccess) {
            System.out.print("Enter username: ");
            String loginUsername = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String loginPassword = scanner.nextLine();
              
            if (loginUsername.equals(userName) && loginPassword.equals(passWord)) {
                System.out.println("Welcome " + userName);
                loginSuccess = true;
            } else {
                System.out.println("Invalid credentials. Please try again.");
            }
        }
        
        scanner.close();
    }

    // --- Input Helper Methods ---

    public static String getValidUsername(Scanner scanner) {
        String username;
        while (true) {
            System.out.print("Enter username (must contain '_' and be <= 5 chars): ");
            username = scanner.nextLine();
            if (checkUserName(username)) {
                System.out.println("Username successfully captured.");
                break;
            } else {
                System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            }
        }
        return username;
    }

    public static String getValidPassword(Scanner scanner) {
        String password;
        while (true) {
            System.out.print("Enter password: ");
            password = scanner.nextLine();
            if (checkPasswordComplexity(password)) {
                System.out.println("Password successfully captured.");
                break;
            } else {
                System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
            }
        }
        return password;
    }

    public static String getValidPhonenumber(Scanner scanner) {
        String phone;
        while (true) {
            System.out.print("Enter cell phone number (+27 format): ");
            phone = scanner.nextLine();
            if (checkCellPhoneNumber(phone)) {
                System.out.println("Cell phone number successfully captured.");
                break;
            } else {
                System.out.println("Cell phone number is invalid. Must start with +27 followed by 9 digits.");
            }
        }
        return phone;
    }

    public static boolean registerUser(String username, String password, String phone) {
        if (checkUserName(username) && checkPasswordComplexity(password) && checkCellPhoneNumber(phone)) {
            System.out.println("User registered successfully!");
            return true;
        }
        return false;
    }

    // --- Validation Methods ---

    public static boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    public static boolean checkPasswordComplexity(String password) {
        // Must contain at least 8 chars, 1 uppercase, 1 digit, and 1 special character
        String pattern = "^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>/?]).{8,}$";
        return password != null && Pattern.matches(pattern, password);
    }

    public static boolean checkCellPhoneNumber(String phoneNumber) {
        // Starts with +27 followed by exactly 9 digits
        String pattern = "^\\+27\\d{9}$";
        return phoneNumber != null && Pattern.matches(pattern, phoneNumber);
    }
}